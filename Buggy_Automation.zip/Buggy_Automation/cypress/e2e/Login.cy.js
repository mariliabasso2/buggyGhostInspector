/// <reference types="cypress"/>
describe('Opening URL', () => {
  beforeEach(() => {
    cy.visit('https://buggy.justtestit.org/')
  })

describe("Login/Logout", () => {
  it("Logs in successfully", () => {
    cy.get('input[name="login"]').type("Mariaaaa")
    cy.get('input[name="password"]').type("Test123@")
    cy.contains("Login").click()
  })

  it("LogOut", () => {
    cy.get('input[name="login"]').type("Mariaaaa")
    cy.get('input[name="password"]').type("Test123@")
    cy.contains("Login").click()
    cy.contains("Logout").click()

  })
  it("Logs in with invalid credentials", () => {
    cy.get('input[name="login"]').type("Mariaaaaa")
    cy.get('input[name="password"]').type("Test123@a")
    cy.contains("Login").click()
    cy.contains('Invalid username/password') //making sure error message is presented
    
  })

})

})